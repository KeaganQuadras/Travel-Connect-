# TravelApp
TravelConnect-Backend: The Express.js backend for TravelConnect, the social travel companion app. Powers destination details, attraction recommendations, user reviews, and more. Join us in shaping the future of travel exploration!
