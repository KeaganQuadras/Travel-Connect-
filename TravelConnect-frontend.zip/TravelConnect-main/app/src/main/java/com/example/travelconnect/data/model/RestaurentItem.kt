package com.example.travelconnect.data.model

data class RestaurentItem(
    val name: String,
    val city: String,
    val img: String,
    val rating: Float
)
