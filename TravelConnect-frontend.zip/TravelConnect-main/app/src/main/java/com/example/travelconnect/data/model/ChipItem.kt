package com.example.travelconnect.data.model

data class ChipItem(val text: String)

