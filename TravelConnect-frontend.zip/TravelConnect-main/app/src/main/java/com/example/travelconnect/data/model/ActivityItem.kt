data class ActivityItem(
    val name: String,
    val province: String,
    val img: String,
    val rating: Float
)
