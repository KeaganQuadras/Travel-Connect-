class ImageModel {
    val name: String? = null
    val img: String? = null
}