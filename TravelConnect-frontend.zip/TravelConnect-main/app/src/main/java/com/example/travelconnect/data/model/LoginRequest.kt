package com.example.travelconnect.data.model

data class LoginRequest(
    val email: String,
    val password: String
)