package com.example.travelconnect.data.model

data class CardItemTypeThree(
    val imageResId: Int,
    val title: String,
    val location: String,
    val rating: Float,
    val ratingCount: String
)
