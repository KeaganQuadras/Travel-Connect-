package com.example.travelconnect.data.model

data class SignUpRequest(
    val email: String,
    val password: String
)
